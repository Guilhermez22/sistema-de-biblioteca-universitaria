function Relatorios(){
    return(
        <>
            <h1>Relatorios Page</h1>
        </>
    )
}
export default Relatorios;